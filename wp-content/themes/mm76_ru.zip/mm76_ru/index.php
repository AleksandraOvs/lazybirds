<?php get_header() ?>
<section>
    <div class="cont">
        index page
    </div>
</section>

<?php get_footer() ?>