</main>

<footer>
    <div class="cont footer-inner">
		<?php
	    	wp_nav_menu(
	        	array(
			    	'theme_location' => 'menu-footer',
			    	'container' => 'nav',
			    	'menu_class' => 'footer__menu',
		    	)
        	);
    	?>

		<div class="footer-inner__block">
			<a href="<?php site_url(); ?>" class="logo_footer">
  				<?php
  					$footer_logo = get_theme_mod('footer_logo');
  					$img = wp_get_attachment_image_src($footer_logo, 'full');
  					if ($img) :
    			?>
    				<img src="<?php echo $img[0]; ?>" alt="">
  				<?php endif; ?>
	    	</a>

			<?php if ( is_active_sidebar( 'footer-contacts-widget' ) ){ ?>    
			<div class="footer-contacts__widget">	
				<div class="footer-desc">
					<span>Стань частью нашего сообщества!</span>
				</div>
				<?php dynamic_sidebar( 'footer-contacts-widget' ); ?>
			</div>
			<?php } ?> 
		</div>
       
		<?php if ( is_active_sidebar( 'footer-docs-widget' ) ){ ?>    
			<div class="footer-docs__widget">
				<div class="footer-docs__widget__info">
					<p>ИП&nbsp;Артемьева Юлия Андреевна</p>
					<p>ОГРН&nbsp;320774600326343 / ИНН&nbsp;502982626269</p>
				</div>	
				<?php dynamic_sidebar( 'footer-docs-widget' ); ?>
			</div>
		<?php } ?>
    </div>
</footer>

<script>
    $ajax = '<?php echo admin_url( "admin-ajax.php" ) ?>';
</script>

<div class="overlay"></div>

<?php wp_footer(); ?>
