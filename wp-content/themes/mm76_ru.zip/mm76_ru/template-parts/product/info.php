<ul class="additional-product-information">
  <li><span> <img src="https://lazybirds.ru/wp-content/themes/lazybirds/assets/img/svg/branded-packaging.svg"> </span>Фирменная упаковка</li>
  <li><span> <img src="https://lazybirds.ru/wp-content/themes/lazybirds/assets/img/svg/delivery.svg"> </span><a href="https://lazybirds.ru/dostavka"> Доставка </a>&nbsp;по всей России</li>
  <li><span> <img src="https://lazybirds.ru/wp-content/themes/lazybirds/assets/img/svg/return.svg"> </span>7 дней на &nbsp; <a href="https://lazybirds.ru/vozvrat">возврат</a></li>
</ul>